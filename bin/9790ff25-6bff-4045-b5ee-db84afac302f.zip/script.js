
/* ==============================
   JS EASY - BASIC JAVASCRIPT
   ============================== */

function selectAnswer(button) {
    var answers = document.querySelectorAll(".answer");

    for (var i = 0; i < answers.length; i++) {
        answers[i].classList.remove("selected");
    }

    button.classList.add("selected");

    var selectedInput = document.getElementById("selectedAnswer");

    if (selectedInput) {
        selectedInput.value = button.innerText;
    }
}

function nextQuestion() {
    var selected = document.querySelector(".answer.selected");

    if (!selected) {
        alert("Please select an answer first.");
        return;
    }

    alert("Answer saved. Next question is ready.");
}

function runCode() {
    var output = document.getElementById("lessonOutput");

    if (output) {
        output.innerHTML = "> Alex";
    }
}

function markComplete() {
    alert("Lesson marked as complete!");
}

function sendMessage() {
    var name = document.getElementById("name");
    var email = document.getElementById("email");
    var message = document.getElementById("message");

    if (name.value == "" || email.value == "" || message.value == "") {
        alert("Please fill in all fields.");
        return;
    }

    alert("Your message has been sent!");
}

function createAccount() {
    var name = document.getElementById("registerName");
    var email = document.getElementById("registerEmail");
    var password = document.getElementById("registerPassword");

    if (name.value == "" || email.value == "" || password.value == "") {
        alert("Please fill in all fields.");
        return;
    }

    alert("Account created successfully!");
}

function startLearning() {
    window.location.href = "dashboard.html";
}
